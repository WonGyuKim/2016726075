#!/bin/bash

echo "===print file information==="
directory=`pwd`

echo "current directory : $directory"
numb_line=`ls $directory | wc -l`
echo "the number of elements : $numb_line"
